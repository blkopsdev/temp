<?php
	$myfile = fopen("matlas.txt", "a+");
	$txt = time()."\n\n";
	fwrite($myfile, $txt);
	fwrite($myfile, print_r($_POST,true));
	fwrite($myfile, print_r($_REQUEST,true));
	fclose($myfile);
	echo '<pre>';
		var_dump($_POST);
	echo '</pre>';
?>